import "regenerator-runtime";
import "./script/component/nav-bar.js";
import "./script/component/list-bar.js";
import "./styles/style.css";
import Bootstrap from 'bootstrap/dist/css/bootstrap.min.css';
import Bootstrap_js from 'bootstrap/dist/js/bootstrap.bundle.min.js';
import main from "./script/view/main.js";



document.addEventListener("DOMContentLoaded", main);