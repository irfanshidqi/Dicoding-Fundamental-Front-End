
const baseUrl = `https://api.themoviedb.org/3/movie/`;
const Key = `fd8633abe7f0cb191f4793f2ad69276a`;

class DataApi {
   static getMovieNya(keyword) {
       return fetch(`${baseUrl}popular?api_key=${Key}&language=en-US&page=1`)
       .then(response => {
           return response.json();
       })
       .then(responseJson => {
        // console.log(responseJson.results)
           if(responseJson.results) {
               return Promise.resolve(responseJson.results);
           } else {
               return Promise.reject(`Error Ada yang salah !`);
           }
       })
   }
}

export default DataApi;