
import './movie-item.js';

class MovieList extends HTMLElement{
    set res_film(res_film) {
        this._res_film = res_film;
        this.render();
        // console.log(res_film.length);
    }

    render() {
        this.innerHTML = "";
        this._res_film.forEach(filmnya => {
        	// console.log(no++)
            const movieElementList = document.createElement("movie-item");
            
			movieElementList.className = "col-lg-4 col-md-6 col-sm-6 col-xs-8 mb-4 box-card";

            movieElementList.filmnya = filmnya;
            this.appendChild(movieElementList);
        	// console.log(filmnya)

        })
    }

    renderError(message) {
    	console.log(message);

        this.innerHTML = "";
        this.innerHTML += `<h3>${message}</h3>`;
    }
}

customElements.define("movie-list", MovieList);