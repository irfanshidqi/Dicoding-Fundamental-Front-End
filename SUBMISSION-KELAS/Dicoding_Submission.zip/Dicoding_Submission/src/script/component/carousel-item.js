 class CarouselItem extends HTMLElement {
    set response(response) {
        this._response = response;
        this.render();
    }

    render() {

        this.innerHTML = `

              <img class="d-block img-fluid w-100" src="https://image.tmdb.org/t/p/w220_and_h330_bestv2/${this._response.backdrop_path}" alt="First slide">
				  <div class="carousel-caption  d-md-block">
				    <h5>${this._response.original_title}</h5>
				    <p>Vote: ${this._response.vote_average}</p>
				  </div>
`;
    }
}
 
customElements.define("carousel-item", CarouselItem);