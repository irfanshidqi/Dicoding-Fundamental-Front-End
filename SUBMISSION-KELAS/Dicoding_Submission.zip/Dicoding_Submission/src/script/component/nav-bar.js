class NavBar extends HTMLElement {
   connectedCallback(){
       this.render();
   }
 
   render() {
       this.innerHTML = `  
	       <nav class="navbar navbar-expand-lg  fixed-top" style="margin-top: 5px;">
	    <div class="container">
	      <a class="navbar-brand" href="#">Submission Dicoding - API Movie</a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="navbar-toggler-icon"></span>
	      </button>
	      <div class="collapse navbar-collapse" id="navbarResponsive">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item active">
				<img src="https://d17ivq9b7rppb3.cloudfront.net/small/avatar/201909051259517ab6f24c66403c4ce7a67cf360e3be77.jpg" alt="Avatar" class="rounded-circle"  width="40" height="40">
	          </li>
	          <li class="nav-item">
	            <a class="nav-link" href="#">muhammad irfan shidqi laksono</a>
	          </li>
	        </ul>
	      </div>
	    </div>
	  </nav>`;
   }
}

customElements.define("nav-bar", NavBar);
