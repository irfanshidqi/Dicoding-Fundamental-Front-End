class ListBar extends HTMLElement{
    connectedCallback(){
        this.render();
    }

    render() {
        this.innerHTML = `
        <div class="list-group my-4">
          <a href="#" class="list-group-item my-3">Populer</a>
          <a href="#" class="list-group-item my-3">Trending</a>
          <a href="#" class="list-group-item my-3">2020</a>
        </div>

       `;

    }
}

customElements.define("list-bar", ListBar);