
import './carousel-item.js';

class CarouselBar extends HTMLElement{
    set res(res) {
        this._res = res;
        this.render();
        // console.log(res.length);
    }

    render() {
    	let no_carousel = 0;
        this.innerHTML = "";
        this._res.forEach(response => {
        	// console.log(no++)
            const CrItemElement = document.createElement("carousel-item");
	            if (no_carousel == 1 ) {
					CrItemElement.className = "carousel-item active";

	            }else{
					CrItemElement.className = "carousel-item";

	            }
            CrItemElement.response = response;
            this.appendChild(CrItemElement);
        	// console.log(response)

        	const CarouselIndicator = document.querySelector('.carousel-indicators');
        	CarouselIndicator.innerHTML += `
           		 <li data-target="#carouselExampleIndicators" data-slide-to="${no_carousel}" class=""></li>
            `;
        	no_carousel++;
        })
    }

    renderError(message) {
    	console.log(message);
        this.innerHTML = "";
        this.innerHTML += `<h3>${message}</h3>`;
    }
}

customElements.define("carousel-bar", CarouselBar);