 class MovieItem extends HTMLElement {
    set filmnya(filmnya) {
        this._filmnya = filmnya;
        this.render();
    }

    render() {


        this.innerHTML = `
            <div class="card h-100 scrollable disable-scrollbars" > 
              <a href="#"><img class="card-img-top" src="https://image.tmdb.org/t/p/w220_and_h330_bestv2/${this._filmnya.backdrop_path}" alt="" width="300" height="300"></a>
              <div class="card-body" >
                <h6 class="card-title">
                  <a href="#">${this._filmnya.original_title}</a>
                </h6>
                <h6>${this._filmnya.release_date}</h6>
                <p class="card-text">${this._filmnya.overview}</p>
              </div>
            </div>
`;
    }
}
 
customElements.define("movie-item", MovieItem);