import $ from 'jquery';
import DataApi from '../data/data-api.js';
import '../component/carousel-bar.js';
import '../component/movie-list.js';
import '../component/list-bar.js';

const main = () => {

    const carouselListElement = document.querySelector("carousel-bar");
    const movieListElement = document.querySelector("movie-list");

    const getMoviePopular = async () => {
        try{
            const result = await DataApi.getMovieNya();
            renderMovie(result);
            // console.log(result);
        } catch (message) {
            fallbackMovie(message)
        }
    };
    const renderMovie =  results => {
// bagian listcarousel
        carouselListElement.res = results;
// bagian listmovie
        movieListElement.res_film = results;

    };

    const fallbackMovie = message => {
        carouselListElement.renderError(message);
        console.log(message);

    };


    getMoviePopular();

    $(function() {


        $(window).scroll(function() {
            const scroll = $(window).scrollTop();
            if (scroll >= 97) {
                $(".navbar").addClass('nav-warna');
            } else {
                $(".navbar").removeClass("nav-warna");
            }
        });
    });

};

export default main;